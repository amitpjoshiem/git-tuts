

import React from 'react'

export const Navigation = () => {
  return (
    <div className="border-b bg-slate-100">
      <nav className="container flex  items-right">
        <div className="font-bold">Employee Login Details</div>
        
      </nav>
    </div>
  )
}
