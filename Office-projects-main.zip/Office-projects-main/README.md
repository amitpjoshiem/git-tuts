# Office-projects
## introduction
##Authentication form
The repository contains the complete source code for the form, including the
Input component and validation configurations.I have developed the form using React.js , tailwind css , nodejs . 

##CURD form
I have created the form using reactjs , tailwind css , node.js and sql. 



## Getting Started

To get started with the project in your local development environment, follow
these steps:

1. Clone the repository to your local machine.

```bash
https://github.com/Japneetsingh123/Office-projects.git
```

2. Open the cloned folder in your preferred code editor, install the required
   dependencies by running the following command in the terminal:

```bash
npm install

```

4. Start the development server by running the following command:

```bash
npm run build
npm start
```

You are now ready to go!


